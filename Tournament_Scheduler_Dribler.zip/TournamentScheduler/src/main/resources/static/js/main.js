console.log("Js loaded");

function validateForm() {

	var team= document.getElementById("team").value;
	var pool= document.getElementById("pool").value;
	var qual= document.getElementById("qual").value;
	 if (team == "" || pool == "" || qual == "" || team <=0 || pool <=0 || qual <=0 || team%pool != 0 ) {
		    alert("All the Fields are Mandatory and Value Should be Greater than 0 And No. Of Teams Should Be A Multiple Of No. Of Pools");
		  }
	 else{
		  loadAllNewsArticle();
	  }
	}
function displayTables1(data1) {
	var divhead = document.getElementById("heading");
	var stng = document.createElement('strong');
	var h2tag = document.createElement('h2');
	var h6tag = document.createElement('h6');
	var br = document.createElement('br');
	h2tag.innerHTML = "..Here It Goes..";
	h6tag.innerHTML = "(You Can Download it By The Link Provided Below)";
	h2tag.setAttribute('align','center');
	h6tag.setAttribute('align','center');
	stng.append(h2tag);
	divhead.append(stng);
	divhead.append(br);
	divhead.append(h6tag);
	var poolNumber = 1;
	var matchNumber = 1;
	var divMain = document.getElementById("main");
	var divpool = document.createElement('div');
	divpool.setAttribute('id','remove1');
	for (var i = 0; i < data1.length; i++) {
		matchNumber = 1;
		var pool = data1[i];
		var div1 = document.createElement('div');
		div1.className = 'container';
		var h2tag = document.createElement('h2');
		h2tag.innerHTML = "Pool "+poolNumber;
		var table1 = document.createElement('table');
		var thead = document.createElement('thead');
		var tr1 = document.createElement('tr');
		var th1 = document.createElement('th');
		th1.innerHTML = "Match No";
		th1.setAttribute('align','center');
		var th2 = document.createElement('th');
		th2.innerHTML = "Teams";
		th2.setAttribute('align','center');
		tr1.appendChild(th1);
		tr1.appendChild(th2);
		thead.appendChild(tr1);
		var tbody = document.createElement('tbody');
		for (var j = 0; j < pool.length; j++) {
			var fixture = pool[j];
			var tr3 = document.createElement('tr');
			var td1 = document.createElement('td');
			td1.innerHTML = matchNumber;
			var td2 = document.createElement('td');
			td2.innerHTML = fixture;
			tr3.appendChild(td1);
			tr3.appendChild(td2);
			tbody.appendChild(tr3);
			matchNumber++;
		}
		poolNumber++;
		table1.appendChild(thead);
		table1.appendChild(tbody);
		div1.appendChild(h2tag);
		table1.setAttribute('border',2);
		div1.appendChild(table1);
		var br = document.createElement('br');
		div1.appendChild(br);
		divpool.appendChild(div1);
	}

	divMain.appendChild(divpool);
}



function displayTables2(data2) {
	var divMain = document.getElementById("main2");
	var div2 = document.createElement('div');
	var divknock = document.createElement('div');
	divknock.setAttribute('id','remove2');
	var h1tag = document.createElement('h1');
	h1tag.innerHTML = "..........Knock Outs..........";
	h1tag.setAttribute('align','center');
	if (data2.length > 0) {
		var divBye = document.createElement('div');
		var table2 = document.createElement('table');
		var thead1 = document.createElement('thead');
		var trb = document.createElement('tr');
		var thb = document.createElement('th');
		thb.innerHTML = "Teams On Bye for first Round Of KnockOut";
		thb.setAttribute('align','center');
		trb.appendChild(thb);
		thead1.appendChild(trb);
		var tbodyb = document.createElement('tbody');
		for (var j = 0; j < data2.length; j++) {
			var trb = document.createElement('tr');
			var tdb = document.createElement('td');
			tdb.innerHTML = data2[j];
			trb.appendChild(tdb);
			tbodyb.appendChild(trb);
		}
		table2.appendChild(thead1);
		table2.appendChild(tbodyb);
		table2.setAttribute('border',2);
		divBye.appendChild(table2);
		var br = document.createElement('br');
		divBye.appendChild(br);
		divknock.appendChild(divBye);
		divknock.appendChild(h1tag);
		divknock.setAttribute('align','center');
		div2.appendChild(divknock);
		divMain.appendChild(div2);
	}else{
		divknock.appendChild(h1tag);
		div2.appendChild(divknock);
		divMain.appendChild(div2);
	}
}
function displayTables3(data3) {
	var divMain = document.getElementById("main3");
	var divKRound = document.createElement('div');
	divKRound.setAttribute('id','remove3');
	var roundNumber = 1;
	var matchNumber = 1;
	for (var i = 0; i < data3.length; i++) {
		var list_knock = data3[i];
		var div1 = document.createElement('div');
		div1.className = 'container';
		if (roundNumber == data3.length) {
			var h2tag = document.createElement('h2');
			h2tag.innerHTML = ".......Finals......";
			div1.appendChild(h2tag);
		} else {
			var h3tag = document.createElement('h3');
			h3tag.innerHTML = "Knock Out Round " + roundNumber;
			div1.appendChild(h3tag);
		}
		var table1 = document.createElement('table');
		var thead = document.createElement('thead');
		var tr1 = document.createElement('tr');
		var th1 = document.createElement('th');
		th1.innerHTML = "Match No";
		th1.setAttribute('align','center');
		var th2 = document.createElement('th');
		th2.innerHTML = "Teams";
		//th2.setAttribute('align','center');
		tr1.appendChild(th1);
		tr1.appendChild(th2);
		thead.appendChild(tr1);
		var tbody = document.createElement('tbody');
		for (var j = 0; j < list_knock.length; j++) {
			var knockout = list_knock[j];
			var tr3 = document.createElement('tr');
			var td1 = document.createElement('td');
			td1.innerHTML = "Match " + matchNumber;
			var td2 = document.createElement('td');
			td2.innerHTML = knockout;
			tr3.appendChild(td1);
			tr3.appendChild(td2);
			tbody.appendChild(tr3);
			matchNumber++;
		}
		roundNumber++;
		table1.appendChild(thead);
		table1.appendChild(tbody);
		table1.setAttribute('border',2);
		div1.appendChild(table1);

		var br = document.createElement('br');
		div1.appendChild(br);
		divKRound.appendChild(div1);
	}
	divMain.appendChild(divKRound);
	
	var divbtn = document.getElementById("downloadButton");
	var stng = document.createElement('strong');
	var h2tag = document.createElement('h4');
	var atag = document.createElement('a');
	atag.setAttribute('href','files/Tournament Schedule.csv');
	h2tag.innerHTML = "Download Schedule";
	atag.append(h2tag);
	stng.append(atag);
	divbtn.append(stng);
	
}

function loadAllNewsArticle() {
	
	if(document.getElementById('remove3'))
		{
		div=document.getElementById('remove3');
		div.remove();
		}
	
	if(document.getElementById('remove2'))
		{
		div=document.getElementById('remove2');
		div.remove();
		}
	
	if(document.getElementById('remove1'))
		{
		div=document.getElementById('remove1');
		div.remove();
		}
	var team= document.getElementById("team").value;
	var pool= document.getElementById("pool").value;
	var qual= document.getElementById("qual").value;
	if(document.getElementById('formremove'))
	{
	div=document.getElementById('formremove');
	div.remove();
	}
	
	$
			.get(
					"http://localhost:8080/rest/FixtureOfPoolMatches/?teams="+team+"&pools="+pool+"&qualifying="+qual,
					function(data, status) {
						displayTables1(data);
					});
	$
			.get(
					"http://localhost:8080/rest/TeamsInByesFor1stKnockOUtRound/?teams="+team+"&pools="+pool+"&qualifying="+qual,
					function(data, status) {
						displayTables2(data);

					});
	$
			.get(
					"http://localhost:8080/rest/FixtureOfKnockOutMatches/?teams="+team+"&pools="+pool+"&qualifying="+qual,
					function(data, status) {
						displayTables3(data);

					});

	$
			.get(
					"http://localhost:8080/rest/generateCSVFile/?teams="+team+"&pools="+pool+"&qualifying="+qual,
					function(data, status) {
					});

}
