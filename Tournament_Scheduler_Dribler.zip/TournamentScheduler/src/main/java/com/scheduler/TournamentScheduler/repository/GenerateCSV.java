package com.scheduler.TournamentScheduler.repository;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.opencsv.CSVWriter;
import com.scheduler.TournamentScheduler.dto.Fixture;

public class GenerateCSV {

	public static void main(String[] args) {}

	private static final String OBJECT_LIST_SAMPLE = System.getProperty("user.dir") + File.separatorChar + "src" + File.separatorChar + "main"
			 + File.separatorChar + "resources" + File.separatorChar +  "static" + File.separatorChar + "files"+ File.separatorChar + "Tournament Schedule.csv";

	public void writeIntoCSV(List<List<String>> poolMatches, List<List<String>> knockOutMatches,
			List<String> teamOnByes) {
		System.out.println("Writing into "+OBJECT_LIST_SAMPLE);
		int poolNumber = 1;
		int matchNumber = 1;

		File file = new File(OBJECT_LIST_SAMPLE);
		try {
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile, '|', CSVWriter.NO_QUOTE_CHARACTER,
					CSVWriter.DEFAULT_ESCAPE_CHARACTER, CSVWriter.DEFAULT_LINE_END);
			String[] nextLine = { "" };
			writer.writeNext(nextLine);
			for (List<String> fix : poolMatches) {
				String[] header = { "Pool : " + String.valueOf(poolNumber) + " Matches" };
				writer.writeNext(header);
				
				writer.writeNext(nextLine);
				List<String[]> data = new ArrayList<String[]>();
				for (String match : fix) {
					data.add(new String[] { "Match  " + String.valueOf(matchNumber), match.toString() });
					matchNumber++;
				}
				writer.writeAll(data);
				poolNumber++;
				writer.writeNext(nextLine);
				writer.writeNext(nextLine);
			}

			if (teamOnByes.size() > 0) {
				String[] header = { "Team On Byes For First KnockOUt Round" };
				writer.writeNext(header);
				writer.writeNext(nextLine);
				List<String[]> data = new ArrayList<String[]>();
				for (String team : teamOnByes) {
					data.add(new String[] { team });
					matchNumber++;
				}
				writer.writeAll(data);
			}

			writer.writeNext(nextLine);
			writer.writeNext(nextLine);

			String[] knockheader = { "........Knock Out Rounds........" };
			writer.writeNext(knockheader);
			int roundNumber = 1;
			matchNumber = 1;

			writer.writeNext(nextLine);
			for (List<String> fix : knockOutMatches) {
				matchNumber = 1;
				String[] header;
				if (roundNumber == knockOutMatches.size())
					header = new String[] { "....Finals...." };
				else
					header = new String[] { "Knock Out Round : " + roundNumber };
				writer.writeNext(header);

				writer.writeNext(nextLine);
				List<String[]> data = new ArrayList<String[]>();
				for (String match : fix) {
					data.add(new String[] { "Match  " + String.valueOf(matchNumber), match.toString() });
					matchNumber++;
				}
				writer.writeAll(data);
				roundNumber++;

				writer.writeNext(nextLine);
				writer.writeNext(nextLine);
			}
			writer.flush();
			writer.close();
		
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
