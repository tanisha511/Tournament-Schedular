package com.scheduler.TournamentScheduler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TournamentSchedulerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TournamentSchedulerApplication.class, args);
	}

}
