package com.scheduler.TournamentScheduler.dto;

public class Tournament {

	int numberOfTeams;
	int numberOfPools;
	int numberOfTeamsQualifying;
	
	public Tournament() {
	}
		public Tournament(int numberOfTeams, int numberOfPools, int numberOfTeamsQualifying) {
		this.numberOfTeams = numberOfTeams;
		this.numberOfPools = numberOfPools;
		this.numberOfTeamsQualifying = numberOfTeamsQualifying;
	}
	public int getNumberOfTeams() {
		return numberOfTeams;
	}
	public void setNumberOfTeams(int numberOfTeams) {
		this.numberOfTeams = numberOfTeams;
	}
	public int getNumberOfPools() {
		return numberOfPools;
	}
	public void setNumberOfPools(int numberOfPools) {
		this.numberOfPools = numberOfPools;
	}
	public int getNumberOfTeamsQualifying() {
		return numberOfTeamsQualifying;
	}
	public void setNumberOfTeamsQualifying(int numberOfTeamsQualifying) {
		this.numberOfTeamsQualifying = numberOfTeamsQualifying;
	}
	
	
}
