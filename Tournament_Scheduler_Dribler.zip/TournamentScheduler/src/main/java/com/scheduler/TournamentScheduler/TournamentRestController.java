package com.scheduler.TournamentScheduler;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scheduler.TournamentScheduler.dto.Tournament;
import com.scheduler.TournamentScheduler.repository.GenerateCSV;
import com.scheduler.TournamentScheduler.repository.Schedule;

@RestController
@RequestMapping("rest")
public class TournamentRestController {
	
	@Autowired
	Schedule schRef;
	
	List<List<String>> list_Of_All = new ArrayList<List<String>>();
	List<String> listOfTeamsInByes = new ArrayList<String>();
	
	List<List<String>> list_Of_All2 = new ArrayList<List<String>>();
	 
	@RequestMapping(value="/FixtureOfPoolMatches",method = RequestMethod.GET,produces="application/json")
	public List<List<String>> PoolMatches(@RequestParam(value = "teams") String numberOfTeams,
			@RequestParam(value = "pools") String numberOfPools,@RequestParam(value = "qualifying") String numberOfTeamsQualifying) {
		Tournament tournament = new Tournament(Integer.parseInt(numberOfTeams), Integer.parseInt(numberOfPools), Integer.parseInt(numberOfTeamsQualifying));
		 list_Of_All=schRef.getSchedule(tournament);
		 System.out.println(list_Of_All);
		 return list_Of_All;
	}
	@RequestMapping(value="/FixtureOfKnockOutMatches",method = RequestMethod.GET,produces="application/json")
	public List<List<String>> KnockoutMatches(@RequestParam(value = "teams") String numberOfTeams,
			@RequestParam(value = "pools") String numberOfPools,@RequestParam(value = "qualifying") String numberOfTeamsQualifying) {
		Tournament tournament = new Tournament(Integer.parseInt(numberOfTeams), Integer.parseInt(numberOfPools), Integer.parseInt(numberOfTeamsQualifying));
		list_Of_All2=schRef.KnockOut(tournament);
		 return list_Of_All2;
	}
	@RequestMapping(value="/TeamsInByesFor1stKnockOUtRound",method = RequestMethod.GET,produces="application/json")
	public List<String> TeamInByeFor1stRoundOfKnockOut(@RequestParam(value = "teams") String numberOfTeams,
			@RequestParam(value = "pools") String numberOfPools,@RequestParam(value = "qualifying") String numberOfTeamsQualifying) {
		Tournament tournament = new Tournament(Integer.parseInt(numberOfTeams), Integer.parseInt(numberOfPools), Integer.parseInt(numberOfTeamsQualifying));
		 listOfTeamsInByes=schRef.listOfTeamsOnByesIn1stRoundOfKnockout(tournament);
		 return listOfTeamsInByes;
	}
	@RequestMapping(value="/generateCSVFile",method = RequestMethod.GET)
	public String GenerateCSV(@RequestParam(value = "teams") String numberOfTeams,
			@RequestParam(value = "pools") String numberOfPools,@RequestParam(value = "qualifying") String numberOfTeamsQualifying) {
		Tournament tournament = new Tournament(Integer.parseInt(numberOfTeams), Integer.parseInt(numberOfPools), Integer.parseInt(numberOfTeamsQualifying));
		list_Of_All=schRef.getSchedule(tournament);
		list_Of_All2=schRef.KnockOut(tournament);
		listOfTeamsInByes=schRef.listOfTeamsOnByesIn1stRoundOfKnockout(tournament);
		
		schRef.writeIntoCSV(list_Of_All, list_Of_All2, listOfTeamsInByes);
	       return "Done";	
	}
	
}
