package com.scheduler.TournamentScheduler.repository;
 
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.scheduler.TournamentScheduler.dto.Fixture;
import com.scheduler.TournamentScheduler.dto.Tournament;

@Service
public class Schedule {
	   
	
	public static void main(String[] args) {}

	public void writeIntoCSV(List<List<String>> poolMatches, List<List<String>> knockOutMatches,
			List<String> teamOnByes) {
		GenerateCSV s = new GenerateCSV();
		s.writeIntoCSV(poolMatches, knockOutMatches, teamOnByes);
		
	}
	public List<String> listOfTeamsOnByesIn1stRoundOfKnockout(Tournament tournament)
	{
		 List<String> listOfTeamsKeptOnByes= new ArrayList<String>(); 
		List<String> ListOfTeamsInKnockOuts = new ArrayList<String>();
		int number_Of_Pools = tournament.getNumberOfPools();
		int number_Of_Teams_Qualifying_From_Each_Pool = tournament.getNumberOfTeamsQualifying();
		for (int i = 1; i <= number_Of_Pools; i++) {
			for (int j = 1; j <= number_Of_Teams_Qualifying_From_Each_Pool; j++) {
				ListOfTeamsInKnockOuts.add("Rank " + j + " Of Pool " + i);
			}
		}

		List<String> copyOfListOfTeamInKnockouts = new ArrayList<>(ListOfTeamsInKnockOuts);
		int number_Of_Teams_In_Knockouts = ListOfTeamsInKnockOuts.size();
		int temp = number_Of_Teams_In_Knockouts;
		int number_Of_Byes = 0;
		int nearestPower;
		int diff;
		int number2;
		int number_Of_Teams_Playing_Round1 = 0;
		if (!(isPowerOfTwo(number_Of_Teams_In_Knockouts))) {
			temp = (temp == 0) ? 0 : 32 - Integer.numberOfLeadingZeros(temp - 1);
			temp = temp - 1;
			nearestPower = (int) Math.pow(2, temp);
			diff = number_Of_Teams_In_Knockouts - nearestPower;
			number2 = nearestPower - diff;
			number_Of_Teams_Playing_Round1=2*diff;
			/*
			 * int greater = (((2 * diff) > (2 * number2))) ? 2 * diff : 2 * number2; int
			 * smaller = (((2 * diff) < (2 * number2))) ? 2 * diff : 2 * number2; if
			 * (greater < number_Of_Teams_In_Knockouts) number_Of_Teams_Playing_Round1 =
			 * greater; else number_Of_Teams_Playing_Round1 = smaller;
			 */
			number_Of_Byes = number_Of_Teams_In_Knockouts - number_Of_Teams_Playing_Round1;
			
			System.out.println("First Round is Among " + number_Of_Teams_Playing_Round1 + " Teams");
			List<String> ListOfTeamsFromNextRound = new ArrayList<String>();
		
			ListOfTeamsFromNextRound = copyOfListOfTeamInKnockouts.subList(number_Of_Teams_Playing_Round1,
					number_Of_Teams_In_Knockouts);
			listOfTeamsKeptOnByes = new ArrayList<>(ListOfTeamsFromNextRound);
		}
		
		
		
		
		List<String> tempList = new ArrayList<String>(listOfTeamsKeptOnByes);
		listOfTeamsKeptOnByes.clear();
		return tempList;
		//return listOfTeamsKeptOnByes;
	}
    public List<List<String>> getSchedule(Tournament tournament)
    {
    	   
 	   List<List<String>> list_Of_All = new ArrayList<List<String>>();
		List<List<String>> pools_Of_Teams = new ArrayList<List<String>>();
		List<String> ListTeam = new ArrayList<String>();
		int number_Of_Teams = tournament.getNumberOfTeams();
		for (int i = 1; i <= number_Of_Teams; i++) {
			ListTeam.add("Team " + i);
		}

		int number_Of_Pools = tournament.getNumberOfPools();
		int number_Of_Teams_In_Each_Pools = number_Of_Teams / number_Of_Pools;
		//int number_Of_Teams_Qualifying_From_Each_Pool = tournament.getNumberOfTeamsQualifying();
		
		pools_Of_Teams = chopped(ListTeam, number_Of_Teams_In_Each_Pools);


		List<String> listOfFixtures = new ArrayList<String>();
		for (int i = 0; i < number_Of_Pools; i++) {

			listOfFixtures = ListMatches(pools_Of_Teams.get(i));
			list_Of_All.add(listOfFixtures);
		}

		
		List<List<String>> temp = new ArrayList<List<String>>(list_Of_All);
		list_Of_All.clear();
		return temp;
    	
    }
 
	public void branch(int seed, int level, int limit, List<String> ListOfTeamsInKnockOuts,ArrayList<String> listOfFixturesForKnockOutRounds) {
		int levelSum = (int) Math.pow(2, level) + 1;
		if (limit == level + 1) {
			listOfFixturesForKnockOutRounds.add(
					new Fixture(ListOfTeamsInKnockOuts.get(seed - 1), ListOfTeamsInKnockOuts.get(levelSum - seed - 1)).toString());
			// System.out.println(ListOfTeamsInKnockOuts.get(seed-1)+" vs
			// "+ListOfTeamsInKnockOuts.get(levelSum-seed-1));
			return;
		} else if (seed % 2 == 1) {
			branch(seed, level + 1, limit, ListOfTeamsInKnockOuts,listOfFixturesForKnockOutRounds);
			branch(levelSum - seed, level + 1, limit, ListOfTeamsInKnockOuts, listOfFixturesForKnockOutRounds);
		} else {
			branch(levelSum - seed, level + 1, limit, ListOfTeamsInKnockOuts,listOfFixturesForKnockOutRounds);
			branch(seed, level + 1, limit, ListOfTeamsInKnockOuts,listOfFixturesForKnockOutRounds);
		}
	}

	static boolean isPowerOfTwo(int x) {
		return x != 0 && ((x & (x - 1)) == 0);
	}

	/*public List<List<Fixture>> KnockOutSchedule() {
		return KnockOut(ListOfTeamsInKnockOuts);
	}*/
	public List<List<String>> KnockOut(Tournament tournament) {
		
	    List<List<String>> finalListOfKnockoutFixtures = new ArrayList<List<String>>(); 
		List<String> ListOfTeamsInKnockOuts = new ArrayList<String>();
		 List<List<String>> list_Of_All_Knockouts = new ArrayList<List<String>>();
		//int number_Of_Teams = tournament.getNumberOfTeams();
		int number_Of_Pools = tournament.getNumberOfPools();
		//int number_Of_Teams_In_Each_Pools = number_Of_Teams / number_Of_Pools;
		int number_Of_Teams_Qualifying_From_Each_Pool = tournament.getNumberOfTeamsQualifying();

		
		for (int i = 1; i <= number_Of_Pools; i++) {
			for (int j = 1; j <= number_Of_Teams_Qualifying_From_Each_Pool; j++) {
				ListOfTeamsInKnockOuts.add("Rank " + j + " Of Pool " + i);
			}
		}
		int i;

		List<String> copyOfListOfTeamInKnockouts = new ArrayList<>(ListOfTeamsInKnockOuts);
		int number_Of_Teams_In_Knockouts = ListOfTeamsInKnockOuts.size();
		int temp = number_Of_Teams_In_Knockouts;
		int number_Of_Byes = 0;
		int nearestPower;
		int diff;
		int number2;
		int number_Of_Teams_Playing_Round1 = 0;
		int number_Of_Teams_From_Next_Round = 0;
		if (!(isPowerOfTwo(number_Of_Teams_In_Knockouts))) {
			temp = (temp == 0) ? 0 : 32 - Integer.numberOfLeadingZeros(temp - 1);
			temp = temp - 1;
			nearestPower = (int) Math.pow(2, temp);
			diff = number_Of_Teams_In_Knockouts - nearestPower;
			number2 = nearestPower - diff;
			number_Of_Teams_Playing_Round1=2*diff;
			/*
			 * int greater = (((2 * diff) > (2 * number2))) ? 2 * diff : 2 * number2; int
			 * smaller = (((2 * diff) < (2 * number2))) ? 2 * diff : 2 * number2; if
			 * (greater < number_Of_Teams_In_Knockouts) number_Of_Teams_Playing_Round1 =
			 * greater; else number_Of_Teams_Playing_Round1 = smaller;
			 */
			number_Of_Byes = number_Of_Teams_In_Knockouts - number_Of_Teams_Playing_Round1;
			number_Of_Teams_From_Next_Round = number_Of_Byes + (number_Of_Teams_Playing_Round1 / 2);
			//System.out.println(number_Of_Byes + " Teams are On Bye For 1st Round");
			// System.out.println("Teams playing from next round" +
			// number_Of_Teams_From_Next_Round);
			System.out.println("First Round is Among " + number_Of_Teams_Playing_Round1 + " Teams");
			// List<String> ListOfTeamsRound1 = new ArrayList<String>();
			List<String> ListOfTeamsFromNextRound = new ArrayList<String>();
			// ListOfTeamsRound1 = copyOfListOfTeamInKnockouts.subList(0,
			// number_Of_Teams_Playing_Round1);
			ListOfTeamsFromNextRound = copyOfListOfTeamInKnockouts.subList(number_Of_Teams_Playing_Round1,
					number_Of_Teams_In_Knockouts);
			//listOfTeamsKeptOnByes = new ArrayList<>(ListOfTeamsFromNextRound);
			//System.out.println("Kept on Byes :" + listOfTeamsKeptOnByes);
			int numberOfWinnersFromFirstRound = (number_Of_Teams_From_Next_Round - ListOfTeamsFromNextRound.size());
			//System.out.println("winners to add:" + numberOfWinnersFromFirstRound);
			for (i = 1; i <= numberOfWinnersFromFirstRound; i++) {
				ListOfTeamsFromNextRound.add("Winner Of Match " + i + " Of KnockOut Round 1");
			}
			List<String> listOfFixturesForKnockoutRound1 = new ArrayList<>();
			listOfFixturesForKnockoutRound1 = Round1_OfKnockOUt(
					copyOfListOfTeamInKnockouts.subList(0, number_Of_Teams_Playing_Round1),
					number_Of_Teams_Playing_Round1);
			list_Of_All_Knockouts.add(listOfFixturesForKnockoutRound1);
			finalListOfKnockoutFixtures = fixturesForKnockOutRoundsTeamsAreInPowersOfTwo(ListOfTeamsFromNextRound,
					number_Of_Teams_From_Next_Round, 2,list_Of_All_Knockouts);
		} else {

			finalListOfKnockoutFixtures = fixturesForKnockOutRoundsTeamsAreInPowersOfTwo(copyOfListOfTeamInKnockouts,
					number_Of_Teams_In_Knockouts, 1,list_Of_All_Knockouts);
		}
		List<List<String>> tempList = new ArrayList<List<String>>(finalListOfKnockoutFixtures);
		finalListOfKnockoutFixtures.clear();
		return tempList;
//return finalListOfKnockoutFixtures;
	}

	public List<List<String>> fixturesForKnockOutRoundsTeamsAreInPowersOfTwo(List<String> copyOfListOfTeamInKnockouts,
			int number_Of_Teams_In_Knockouts, int r,List<List<String>> list_Of_All_Knockouts) {
		ArrayList<String> listOfFixturesForKnockOutRounds = new ArrayList<String>();
		ArrayList<String> temp = new ArrayList<>(listOfFixturesForKnockOutRounds);
		int numberTeams = number_Of_Teams_In_Knockouts;
		int temp2 = (numberTeams == 0) ? 0 : 32 - Integer.numberOfLeadingZeros(numberTeams - 1);
		int limit = temp2 + 1;
		int count = r - 1;
		int numberOfTeams = copyOfListOfTeamInKnockouts.size();
		int matchesInRound = numberOfTeams / 2;
		int start = 0;
		int end = matchesInRound;
		for (int round = 1; round < limit; round++) {
			branch(1, 1, limit - round + 1, copyOfListOfTeamInKnockouts,listOfFixturesForKnockOutRounds);
			copyOfListOfTeamInKnockouts.clear();
			for (int j = 0; j < (numberOfTeams / 2); j++) {
				copyOfListOfTeamInKnockouts
						.add("Winner Of Match " + (j + 1) + " In Round " + (round + count) + " of Knockouts");
			}
			temp = new ArrayList<>(listOfFixturesForKnockOutRounds);
			list_Of_All_Knockouts.add(temp.subList(start, end));
			matchesInRound = (matchesInRound / 2);
			start = end;
			end = end + matchesInRound;
		}
		return list_Of_All_Knockouts;
	}

	static List<String> Round1_OfKnockOUt(List<String> ListOfTeamsRound1, int number_Of_Teams_Playing_Round1) {
		int halfSize = number_Of_Teams_Playing_Round1 / 2;
		int teamsSize = number_Of_Teams_Playing_Round1;
		//System.out.println(ListOfTeamsRound1);
		List<String> listOfFixturesForKnockoutRound1 = new ArrayList<String>();

		// String[] array=ListOfTeamsRound1.toArray(new
		// String[ListOfTeamsRound1.size()]);
		for (int idx = 0; idx < halfSize; idx++) {
			int firstTeam = idx % teamsSize;
			int secondTeam = (teamsSize - (idx + 1)) % teamsSize;
			listOfFixturesForKnockoutRound1
					.add(new Fixture(ListOfTeamsRound1.get(firstTeam), ListOfTeamsRound1.get(secondTeam)).toString());
		}

		return listOfFixturesForKnockoutRound1;
	}

	static List<List<String>> chopped(List<String> list, final int L) {
		List<List<String>> pools = new ArrayList<List<String>>();
		final int N = list.size();
		for (int i = 0; i < N; i += L) {
			pools.add(new ArrayList<String>(list.subList(i, Math.min(N, i + L))));
		}
		return pools;
	}

	static List<String> ListMatches(List<String> ListTeam) {
		if (ListTeam.size() % 2 != 0) {
			ListTeam.add("Bye");
		}

		int numDays = (ListTeam.size() - 1);
		int halfSize = ListTeam.size() / 2;

		List<String> teams = new ArrayList<String>();

		teams.addAll(ListTeam);
		teams.remove(0);

		int teamsSize = teams.size();
		List<String> listOfFixtures = new ArrayList<String>();

		for (int day = 0; day < numDays; day++) {
			// System.out.println("Round " + (day + 1));

			int teamIdx = day % teamsSize;
			if (!(teams.get(teamIdx).contains("Bye") || ListTeam.get(0).contains("Bye")))
				listOfFixtures.add(new Fixture(teams.get(teamIdx), ListTeam.get(0)).toString());
			// System.out.println(teams.get(teamIdx) + " vs " +
			// ListTeam.get(0));

			for (int idx = 1; idx < halfSize; idx++) {
				int firstTeam = (day + idx) % teamsSize;
				int secondTeam = (day + teamsSize - idx) % teamsSize;
				if (!(teams.get(firstTeam).contains("Bye") || teams.get(secondTeam).contains("Bye")))
					listOfFixtures.add(new Fixture(teams.get(firstTeam), teams.get(secondTeam)).toString());
				// System.out.println(teams.get(firstTeam) + " vs " +
				// teams.get(secondTeam));
			}
		}
		return listOfFixtures;
	}

}